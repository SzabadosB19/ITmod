﻿CREATE TABLE [dbo].[Ingatlan] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [Cim]        NVARCHAR (50)  NOT NULL,
    [Terulet]    INT            NOT NULL,
    [Szoba]      INT            NOT NULL,
    [Felszoba]   INT            NOT NULL,
    [Komfort]    NVARCHAR (50)  NOT NULL,
    [Futes]      NVARCHAR (50)  NOT NULL,
    [Furdo]      INT            NOT NULL,
    [Epites_eve] DATETIME       NOT NULL,
    [Parkolas]   NVARCHAR (50)  NOT NULL,
    [Leiras]     NVARCHAR (MAX) NOT NULL,
    [Tulajdonos] NVARCHAR (50)  NOT NULL,
    [Ar]         INT            NOT NULL, 
    [Kep] IMAGE NULL, 
    [Email] NVARCHAR(50) NULL, 
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

