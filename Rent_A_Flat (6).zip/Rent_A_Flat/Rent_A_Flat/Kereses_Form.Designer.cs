﻿namespace Rent_A_Flat
{
    partial class Kereses_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Ingatlanok = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cb_parkolas = new System.Windows.Forms.ComboBox();
            this.cb_komfort = new System.Windows.Forms.ComboBox();
            this.label_ar = new System.Windows.Forms.Label();
            this.tb_ar = new System.Windows.Forms.TextBox();
            this.dtp_epiteseve = new System.Windows.Forms.DateTimePicker();
            this.label_parkolas = new System.Windows.Forms.Label();
            this.label_epiteseve = new System.Windows.Forms.Label();
            this.label_furdo = new System.Windows.Forms.Label();
            this.label_futes = new System.Windows.Forms.Label();
            this.label_komfort = new System.Windows.Forms.Label();
            this.label_felszoba = new System.Windows.Forms.Label();
            this.label_szobakszama = new System.Windows.Forms.Label();
            this.label_terulet = new System.Windows.Forms.Label();
            this.label_cim = new System.Windows.Forms.Label();
            this.tb_furdo = new System.Windows.Forms.TextBox();
            this.tb_futes = new System.Windows.Forms.TextBox();
            this.tb_felszoba = new System.Windows.Forms.TextBox();
            this.tb_szobak = new System.Windows.Forms.TextBox();
            this.tb_terulet = new System.Windows.Forms.TextBox();
            this.tb_cim = new System.Windows.Forms.TextBox();
            this.label_leiras = new System.Windows.Forms.Label();
            this.rtb_leiras = new System.Windows.Forms.RichTextBox();
            this.label_elerhetoseg = new System.Windows.Forms.Label();
            this.tb_elerhetosegek = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // lb_Ingatlanok
            // 
            this.lb_Ingatlanok.FormattingEnabled = true;
            this.lb_Ingatlanok.Location = new System.Drawing.Point(31, 73);
            this.lb_Ingatlanok.Name = "lb_Ingatlanok";
            this.lb_Ingatlanok.Size = new System.Drawing.Size(427, 238);
            this.lb_Ingatlanok.TabIndex = 1;
            this.lb_Ingatlanok.SelectedIndexChanged += new System.EventHandler(this.lb_Ingatlanok_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(68, 339);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(357, 196);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // cb_parkolas
            // 
            this.cb_parkolas.FormattingEnabled = true;
            this.cb_parkolas.Items.AddRange(new object[] {
            "közterületen - ingyenes",
            "közterületen - fizetős",
            "belső udvarban",
            "teremgarázsban",
            "garázsban"});
            this.cb_parkolas.Location = new System.Drawing.Point(644, 386);
            this.cb_parkolas.Margin = new System.Windows.Forms.Padding(4);
            this.cb_parkolas.Name = "cb_parkolas";
            this.cb_parkolas.Size = new System.Drawing.Size(217, 21);
            this.cb_parkolas.TabIndex = 78;
            this.cb_parkolas.Visible = false;
            // 
            // cb_komfort
            // 
            this.cb_komfort.FormattingEnabled = true;
            this.cb_komfort.Items.AddRange(new object[] {
            "összkomfortos",
            "duplakomfortos"});
            this.cb_komfort.Location = new System.Drawing.Point(644, 223);
            this.cb_komfort.Margin = new System.Windows.Forms.Padding(4);
            this.cb_komfort.Name = "cb_komfort";
            this.cb_komfort.Size = new System.Drawing.Size(217, 21);
            this.cb_komfort.TabIndex = 77;
            this.cb_komfort.Visible = false;
            // 
            // label_ar
            // 
            this.label_ar.AutoSize = true;
            this.label_ar.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_ar.Location = new System.Drawing.Point(605, 538);
            this.label_ar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ar.Name = "label_ar";
            this.label_ar.Size = new System.Drawing.Size(31, 22);
            this.label_ar.TabIndex = 76;
            this.label_ar.Text = "Ár";
            this.label_ar.Visible = false;
            // 
            // tb_ar
            // 
            this.tb_ar.Location = new System.Drawing.Point(644, 534);
            this.tb_ar.Margin = new System.Windows.Forms.Padding(4);
            this.tb_ar.Name = "tb_ar";
            this.tb_ar.Size = new System.Drawing.Size(217, 20);
            this.tb_ar.TabIndex = 75;
            this.tb_ar.Visible = false;
            // 
            // dtp_epiteseve
            // 
            this.dtp_epiteseve.Location = new System.Drawing.Point(644, 339);
            this.dtp_epiteseve.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_epiteseve.MaxDate = new System.DateTime(2019, 12, 25, 23, 59, 59, 0);
            this.dtp_epiteseve.Name = "dtp_epiteseve";
            this.dtp_epiteseve.Size = new System.Drawing.Size(217, 20);
            this.dtp_epiteseve.TabIndex = 63;
            this.dtp_epiteseve.Value = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.dtp_epiteseve.Visible = false;
            // 
            // label_parkolas
            // 
            this.label_parkolas.AutoSize = true;
            this.label_parkolas.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_parkolas.Location = new System.Drawing.Point(568, 385);
            this.label_parkolas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_parkolas.Name = "label_parkolas";
            this.label_parkolas.Size = new System.Drawing.Size(68, 19);
            this.label_parkolas.TabIndex = 73;
            this.label_parkolas.Text = "Parkolás";
            this.label_parkolas.Visible = false;
            // 
            // label_epiteseve
            // 
            this.label_epiteseve.AutoSize = true;
            this.label_epiteseve.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_epiteseve.Location = new System.Drawing.Point(557, 345);
            this.label_epiteseve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_epiteseve.Name = "label_epiteseve";
            this.label_epiteseve.Size = new System.Drawing.Size(79, 19);
            this.label_epiteseve.TabIndex = 72;
            this.label_epiteseve.Text = "Építés éve";
            this.label_epiteseve.Visible = false;
            // 
            // label_furdo
            // 
            this.label_furdo.AutoSize = true;
            this.label_furdo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_furdo.Location = new System.Drawing.Point(588, 304);
            this.label_furdo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_furdo.Name = "label_furdo";
            this.label_furdo.Size = new System.Drawing.Size(48, 19);
            this.label_furdo.TabIndex = 71;
            this.label_furdo.Text = "Fürdő";
            this.label_furdo.Visible = false;
            // 
            // label_futes
            // 
            this.label_futes.AutoSize = true;
            this.label_futes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_futes.Location = new System.Drawing.Point(590, 266);
            this.label_futes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_futes.Name = "label_futes";
            this.label_futes.Size = new System.Drawing.Size(46, 19);
            this.label_futes.TabIndex = 70;
            this.label_futes.Text = "Fűtés";
            this.label_futes.Visible = false;
            // 
            // label_komfort
            // 
            this.label_komfort.AutoSize = true;
            this.label_komfort.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_komfort.Location = new System.Drawing.Point(571, 226);
            this.label_komfort.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_komfort.Name = "label_komfort";
            this.label_komfort.Size = new System.Drawing.Size(65, 19);
            this.label_komfort.TabIndex = 69;
            this.label_komfort.Text = "Komfort";
            this.label_komfort.Visible = false;
            // 
            // label_felszoba
            // 
            this.label_felszoba.AutoSize = true;
            this.label_felszoba.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_felszoba.Location = new System.Drawing.Point(515, 194);
            this.label_felszoba.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_felszoba.Name = "label_felszoba";
            this.label_felszoba.Size = new System.Drawing.Size(121, 19);
            this.label_felszoba.TabIndex = 68;
            this.label_felszoba.Text = "Félszobák száma";
            this.label_felszoba.Visible = false;
            // 
            // label_szobakszama
            // 
            this.label_szobakszama.AutoSize = true;
            this.label_szobakszama.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_szobakszama.Location = new System.Drawing.Point(534, 152);
            this.label_szobakszama.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_szobakszama.Name = "label_szobakszama";
            this.label_szobakszama.Size = new System.Drawing.Size(102, 19);
            this.label_szobakszama.TabIndex = 67;
            this.label_szobakszama.Text = "Szobák száma";
            this.label_szobakszama.Visible = false;
            // 
            // label_terulet
            // 
            this.label_terulet.AutoSize = true;
            this.label_terulet.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_terulet.Location = new System.Drawing.Point(579, 114);
            this.label_terulet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_terulet.Name = "label_terulet";
            this.label_terulet.Size = new System.Drawing.Size(57, 19);
            this.label_terulet.TabIndex = 66;
            this.label_terulet.Text = "Terület";
            this.label_terulet.Visible = false;
            // 
            // label_cim
            // 
            this.label_cim.AutoSize = true;
            this.label_cim.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_cim.Location = new System.Drawing.Point(600, 77);
            this.label_cim.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_cim.Name = "label_cim";
            this.label_cim.Size = new System.Drawing.Size(36, 19);
            this.label_cim.TabIndex = 65;
            this.label_cim.Text = "Cím";
            this.label_cim.Visible = false;
            // 
            // tb_furdo
            // 
            this.tb_furdo.Location = new System.Drawing.Point(644, 301);
            this.tb_furdo.Margin = new System.Windows.Forms.Padding(4);
            this.tb_furdo.Name = "tb_furdo";
            this.tb_furdo.Size = new System.Drawing.Size(217, 20);
            this.tb_furdo.TabIndex = 62;
            this.tb_furdo.Visible = false;
            // 
            // tb_futes
            // 
            this.tb_futes.Location = new System.Drawing.Point(644, 263);
            this.tb_futes.Margin = new System.Windows.Forms.Padding(4);
            this.tb_futes.Name = "tb_futes";
            this.tb_futes.Size = new System.Drawing.Size(217, 20);
            this.tb_futes.TabIndex = 61;
            this.tb_futes.Visible = false;
            // 
            // tb_felszoba
            // 
            this.tb_felszoba.Location = new System.Drawing.Point(644, 187);
            this.tb_felszoba.Margin = new System.Windows.Forms.Padding(4);
            this.tb_felszoba.Name = "tb_felszoba";
            this.tb_felszoba.Size = new System.Drawing.Size(217, 20);
            this.tb_felszoba.TabIndex = 60;
            this.tb_felszoba.Visible = false;
            // 
            // tb_szobak
            // 
            this.tb_szobak.Location = new System.Drawing.Point(644, 149);
            this.tb_szobak.Margin = new System.Windows.Forms.Padding(4);
            this.tb_szobak.Name = "tb_szobak";
            this.tb_szobak.Size = new System.Drawing.Size(217, 20);
            this.tb_szobak.TabIndex = 59;
            this.tb_szobak.Visible = false;
            // 
            // tb_terulet
            // 
            this.tb_terulet.Location = new System.Drawing.Point(644, 111);
            this.tb_terulet.Margin = new System.Windows.Forms.Padding(4);
            this.tb_terulet.Name = "tb_terulet";
            this.tb_terulet.Size = new System.Drawing.Size(217, 20);
            this.tb_terulet.TabIndex = 58;
            this.tb_terulet.Visible = false;
            // 
            // tb_cim
            // 
            this.tb_cim.Location = new System.Drawing.Point(644, 73);
            this.tb_cim.Margin = new System.Windows.Forms.Padding(4);
            this.tb_cim.Name = "tb_cim";
            this.tb_cim.Size = new System.Drawing.Size(217, 20);
            this.tb_cim.TabIndex = 57;
            this.tb_cim.Visible = false;
            // 
            // label_leiras
            // 
            this.label_leiras.AutoSize = true;
            this.label_leiras.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_leiras.Location = new System.Drawing.Point(584, 452);
            this.label_leiras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_leiras.Name = "label_leiras";
            this.label_leiras.Size = new System.Drawing.Size(52, 19);
            this.label_leiras.TabIndex = 80;
            this.label_leiras.Text = "Leírás";
            this.label_leiras.Visible = false;
            // 
            // rtb_leiras
            // 
            this.rtb_leiras.Location = new System.Drawing.Point(644, 452);
            this.rtb_leiras.Margin = new System.Windows.Forms.Padding(4);
            this.rtb_leiras.Name = "rtb_leiras";
            this.rtb_leiras.Size = new System.Drawing.Size(217, 60);
            this.rtb_leiras.TabIndex = 79;
            this.rtb_leiras.Text = "";
            this.rtb_leiras.Visible = false;
            // 
            // label_elerhetoseg
            // 
            this.label_elerhetoseg.AutoSize = true;
            this.label_elerhetoseg.Location = new System.Drawing.Point(28, 556);
            this.label_elerhetoseg.Name = "label_elerhetoseg";
            this.label_elerhetoseg.Size = new System.Drawing.Size(75, 13);
            this.label_elerhetoseg.TabIndex = 81;
            this.label_elerhetoseg.Text = "Elérhetőségek";
            this.label_elerhetoseg.Visible = false;
            // 
            // tb_elerhetosegek
            // 
            this.tb_elerhetosegek.Location = new System.Drawing.Point(99, 587);
            this.tb_elerhetosegek.Name = "tb_elerhetosegek";
            this.tb_elerhetosegek.Size = new System.Drawing.Size(314, 20);
            this.tb_elerhetosegek.TabIndex = 82;
            this.tb_elerhetosegek.Visible = false;
            // 
            // Kereses_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 619);
            this.Controls.Add(this.tb_elerhetosegek);
            this.Controls.Add(this.label_elerhetoseg);
            this.Controls.Add(this.label_leiras);
            this.Controls.Add(this.rtb_leiras);
            this.Controls.Add(this.cb_parkolas);
            this.Controls.Add(this.cb_komfort);
            this.Controls.Add(this.label_ar);
            this.Controls.Add(this.tb_ar);
            this.Controls.Add(this.dtp_epiteseve);
            this.Controls.Add(this.label_parkolas);
            this.Controls.Add(this.label_epiteseve);
            this.Controls.Add(this.label_furdo);
            this.Controls.Add(this.label_futes);
            this.Controls.Add(this.label_komfort);
            this.Controls.Add(this.label_felszoba);
            this.Controls.Add(this.label_szobakszama);
            this.Controls.Add(this.label_terulet);
            this.Controls.Add(this.label_cim);
            this.Controls.Add(this.tb_furdo);
            this.Controls.Add(this.tb_futes);
            this.Controls.Add(this.tb_felszoba);
            this.Controls.Add(this.tb_szobak);
            this.Controls.Add(this.tb_terulet);
            this.Controls.Add(this.tb_cim);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lb_Ingatlanok);
            this.Controls.Add(this.label1);
            this.Name = "Kereses_Form";
            this.Text = "Kereses_Form";
            this.Load += new System.EventHandler(this.Kereses_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lb_Ingatlanok;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cb_parkolas;
        private System.Windows.Forms.ComboBox cb_komfort;
        private System.Windows.Forms.Label label_ar;
        private System.Windows.Forms.TextBox tb_ar;
        private System.Windows.Forms.DateTimePicker dtp_epiteseve;
        private System.Windows.Forms.Label label_parkolas;
        private System.Windows.Forms.Label label_epiteseve;
        private System.Windows.Forms.Label label_furdo;
        private System.Windows.Forms.Label label_futes;
        private System.Windows.Forms.Label label_komfort;
        private System.Windows.Forms.Label label_felszoba;
        private System.Windows.Forms.Label label_szobakszama;
        private System.Windows.Forms.Label label_terulet;
        private System.Windows.Forms.Label label_cim;
        private System.Windows.Forms.TextBox tb_furdo;
        private System.Windows.Forms.TextBox tb_futes;
        private System.Windows.Forms.TextBox tb_felszoba;
        private System.Windows.Forms.TextBox tb_szobak;
        private System.Windows.Forms.TextBox tb_terulet;
        private System.Windows.Forms.TextBox tb_cim;
        private System.Windows.Forms.Label label_leiras;
        private System.Windows.Forms.RichTextBox rtb_leiras;
        private System.Windows.Forms.Label label_elerhetoseg;
        private System.Windows.Forms.TextBox tb_elerhetosegek;
    }
}