﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_A_Flat
{
    public partial class Profil_Form : Form
    {
        Felhasznalo bejelentkezettFelhasznaloProfil;

        public Felhasznalo BejelentkezettFelhasznaloProfil
        {
            get { return bejelentkezettFelhasznaloProfil; }
            set { bejelentkezettFelhasznaloProfil = value; }
        }

        public Profil_Form()
        {
            InitializeComponent();
            
                
            
        }

        private void btn_modosit_Click(object sender, EventArgs e)
        {
            tb_nev.ReadOnly = false;
            tb_email.ReadOnly = false;
            tb_cim.ReadOnly = false;
            tb_jelszo.ReadOnly = false;
            tb_jelszo_ujra.ReadOnly = false;
            tb_telefon.ReadOnly = false;
            btn_visszavon.Visible = true;
        }

        private void Profil_Form_Load(object sender, EventArgs e)
        {
            tb_cim.Text = bejelentkezettFelhasznaloProfil.Cim;
            tb_email.Text = bejelentkezettFelhasznaloProfil.Email;
            tb_jelszo.Text = bejelentkezettFelhasznaloProfil.Jelszo;
            tb_jelszo_ujra.Text = bejelentkezettFelhasznaloProfil.Jelszo;
            tb_nev.Text = bejelentkezettFelhasznaloProfil.Nev;
            tb_telefon.Text = bejelentkezettFelhasznaloProfil.Telefonszam;
            btn_visszavon.Visible = false;
        }

        private void btn_visszavon_Click(object sender, EventArgs e)
        {
            tb_nev.ReadOnly = true;
            tb_email.ReadOnly = true;
            tb_cim.ReadOnly = true;
            tb_jelszo.ReadOnly = true;
            tb_jelszo_ujra.ReadOnly = true;
            tb_telefon.ReadOnly = true;
            tb_cim.Text = bejelentkezettFelhasznaloProfil.Cim;
            tb_email.Text = bejelentkezettFelhasznaloProfil.Email;
            tb_jelszo.Text = bejelentkezettFelhasznaloProfil.Jelszo;
            tb_jelszo_ujra.Text = bejelentkezettFelhasznaloProfil.Jelszo;
            tb_nev.Text = bejelentkezettFelhasznaloProfil.Nev;
            tb_telefon.Text = bejelentkezettFelhasznaloProfil.Telefonszam;
            btn_visszavon.Visible = false;
        }
    }
}
