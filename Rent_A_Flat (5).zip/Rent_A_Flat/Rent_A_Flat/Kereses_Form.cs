﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_A_Flat
{
    public partial class Kereses_Form : Form
    {

        Felhasznalo keresoFelhasznalo;

        public Felhasznalo KeresoFelhasznalo
        {
            get { return keresoFelhasznalo; }
            set { keresoFelhasznalo = value; }
        }
        public Kereses_Form()
        {
            InitializeComponent();
        }

        private void Kereses_Form_Load(object sender, EventArgs e)
        {
            if (label1.Text=="label1")
            {
                label1.Text = "Jelenleg vendégként böngészed az oldalt, ahhoz, hogy ingatlant tudjál foglalni kérlek jelentkezz be vagy reigsztrálj.";
            } 
            if (keresoFelhasznalo.Nev!="")
            {                
                label1.Text = keresoFelhasznalo.ToString();
            }
            
        }
    }
}
