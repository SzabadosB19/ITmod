﻿namespace Rent_A_Flat
{
    partial class Profil_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_nev = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_cim = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_jelszo_ujra = new System.Windows.Forms.TextBox();
            this.tb_jelszo = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.btn_modosit = new System.Windows.Forms.Button();
            this.tb_telefon = new System.Windows.Forms.TextBox();
            this.btn_visszavon = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_nev
            // 
            this.tb_nev.Location = new System.Drawing.Point(136, 23);
            this.tb_nev.Name = "tb_nev";
            this.tb_nev.ReadOnly = true;
            this.tb_nev.Size = new System.Drawing.Size(100, 20);
            this.tb_nev.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(98, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 46;
            this.label1.Text = "Név";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(278, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 15);
            this.label6.TabIndex = 45;
            this.label6.Text = "Telefonszám";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(319, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 15);
            this.label5.TabIndex = 44;
            this.label5.Text = "Cím";
            // 
            // tb_cim
            // 
            this.tb_cim.Location = new System.Drawing.Point(355, 71);
            this.tb_cim.Name = "tb_cim";
            this.tb_cim.ReadOnly = true;
            this.tb_cim.Size = new System.Drawing.Size(181, 20);
            this.tb_cim.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(16, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 15);
            this.label3.TabIndex = 43;
            this.label3.Text = "Jelszó megerősítése";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(83, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 42;
            this.label2.Text = "Jelszó";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(289, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 41;
            this.label4.Text = "E-mail cím";
            // 
            // tb_jelszo_ujra
            // 
            this.tb_jelszo_ujra.Location = new System.Drawing.Point(136, 123);
            this.tb_jelszo_ujra.Name = "tb_jelszo_ujra";
            this.tb_jelszo_ujra.PasswordChar = '*';
            this.tb_jelszo_ujra.ReadOnly = true;
            this.tb_jelszo_ujra.Size = new System.Drawing.Size(100, 20);
            this.tb_jelszo_ujra.TabIndex = 35;
            // 
            // tb_jelszo
            // 
            this.tb_jelszo.Location = new System.Drawing.Point(136, 78);
            this.tb_jelszo.Name = "tb_jelszo";
            this.tb_jelszo.PasswordChar = '*';
            this.tb_jelszo.ReadOnly = true;
            this.tb_jelszo.Size = new System.Drawing.Size(100, 20);
            this.tb_jelszo.TabIndex = 34;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(355, 23);
            this.tb_email.Name = "tb_email";
            this.tb_email.ReadOnly = true;
            this.tb_email.Size = new System.Drawing.Size(181, 20);
            this.tb_email.TabIndex = 36;
            // 
            // btn_modosit
            // 
            this.btn_modosit.Location = new System.Drawing.Point(355, 167);
            this.btn_modosit.Name = "btn_modosit";
            this.btn_modosit.Size = new System.Drawing.Size(75, 23);
            this.btn_modosit.TabIndex = 47;
            this.btn_modosit.Text = "Módosítás";
            this.btn_modosit.UseVisualStyleBackColor = true;
            this.btn_modosit.Click += new System.EventHandler(this.btn_modosit_Click);
            // 
            // tb_telefon
            // 
            this.tb_telefon.Location = new System.Drawing.Point(355, 118);
            this.tb_telefon.Name = "tb_telefon";
            this.tb_telefon.ReadOnly = true;
            this.tb_telefon.Size = new System.Drawing.Size(181, 20);
            this.tb_telefon.TabIndex = 49;
            // 
            // btn_visszavon
            // 
            this.btn_visszavon.Location = new System.Drawing.Point(355, 167);
            this.btn_visszavon.Name = "btn_visszavon";
            this.btn_visszavon.Size = new System.Drawing.Size(75, 23);
            this.btn_visszavon.TabIndex = 50;
            this.btn_visszavon.Text = "Visszavonás";
            this.btn_visszavon.UseVisualStyleBackColor = true;
            this.btn_visszavon.Click += new System.EventHandler(this.btn_visszavon_Click);
            // 
            // Profil_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 205);
            this.Controls.Add(this.btn_visszavon);
            this.Controls.Add(this.tb_telefon);
            this.Controls.Add(this.btn_modosit);
            this.Controls.Add(this.tb_nev);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_cim);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_jelszo_ujra);
            this.Controls.Add(this.tb_jelszo);
            this.Controls.Add(this.tb_email);
            this.Name = "Profil_Form";
            this.Text = "Profil_Form";
            this.Load += new System.EventHandler(this.Profil_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_nev;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_cim;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_jelszo_ujra;
        private System.Windows.Forms.TextBox tb_jelszo;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Button btn_modosit;
        private System.Windows.Forms.TextBox tb_telefon;
        private System.Windows.Forms.Button btn_visszavon;
    }
}