﻿namespace Rent_A_Flat
{
    partial class Regisztracios_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_nev = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_telefon_1 = new System.Windows.Forms.TextBox();
            this.cb_telefon = new System.Windows.Forms.ComboBox();
            this.tb_telefon_3 = new System.Windows.Forms.TextBox();
            this.tb_cim = new System.Windows.Forms.TextBox();
            this.btn_Regisztrálás = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_jelszo_ujra = new System.Windows.Forms.TextBox();
            this.tb_jelszo = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.btn_createdefault = new System.Windows.Forms.Button();
            this.btn_restore = new System.Windows.Forms.Button();
            this.btn_vissza = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_nev
            // 
            this.tb_nev.Location = new System.Drawing.Point(139, 29);
            this.tb_nev.Name = "tb_nev";
            this.tb_nev.Size = new System.Drawing.Size(100, 20);
            this.tb_nev.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(101, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 32;
            this.label1.Text = "Név";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(281, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 15);
            this.label6.TabIndex = 31;
            this.label6.Text = "Telefonszám";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(322, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 15);
            this.label5.TabIndex = 30;
            this.label5.Text = "Cím";
            // 
            // tb_telefon_1
            // 
            this.tb_telefon_1.Location = new System.Drawing.Point(358, 123);
            this.tb_telefon_1.Name = "tb_telefon_1";
            this.tb_telefon_1.Size = new System.Drawing.Size(33, 20);
            this.tb_telefon_1.TabIndex = 6;
            this.tb_telefon_1.Text = "+36";
            // 
            // cb_telefon
            // 
            this.cb_telefon.FormattingEnabled = true;
            this.cb_telefon.Items.AddRange(new object[] {
            "20",
            "30",
            "70"});
            this.cb_telefon.Location = new System.Drawing.Point(397, 122);
            this.cb_telefon.Name = "cb_telefon";
            this.cb_telefon.Size = new System.Drawing.Size(44, 21);
            this.cb_telefon.TabIndex = 7;
            // 
            // tb_telefon_3
            // 
            this.tb_telefon_3.Location = new System.Drawing.Point(447, 123);
            this.tb_telefon_3.Name = "tb_telefon_3";
            this.tb_telefon_3.Size = new System.Drawing.Size(92, 20);
            this.tb_telefon_3.TabIndex = 8;
            // 
            // tb_cim
            // 
            this.tb_cim.Location = new System.Drawing.Point(358, 77);
            this.tb_cim.Name = "tb_cim";
            this.tb_cim.Size = new System.Drawing.Size(181, 20);
            this.tb_cim.TabIndex = 5;
            // 
            // btn_Regisztrálás
            // 
            this.btn_Regisztrálás.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_Regisztrálás.Location = new System.Drawing.Point(209, 173);
            this.btn_Regisztrálás.Name = "btn_Regisztrálás";
            this.btn_Regisztrálás.Size = new System.Drawing.Size(139, 34);
            this.btn_Regisztrálás.TabIndex = 28;
            this.btn_Regisztrálás.Text = "Regisztráció";
            this.btn_Regisztrálás.UseVisualStyleBackColor = true;
            this.btn_Regisztrálás.Click += new System.EventHandler(this.btn_Regisztrálás_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(19, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 15);
            this.label3.TabIndex = 23;
            this.label3.Text = "Jelszó megerősítése";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(86, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 22;
            this.label2.Text = "Jelszó";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(292, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 19;
            this.label4.Text = "E-mail cím";
            // 
            // tb_jelszo_ujra
            // 
            this.tb_jelszo_ujra.Location = new System.Drawing.Point(139, 129);
            this.tb_jelszo_ujra.Name = "tb_jelszo_ujra";
            this.tb_jelszo_ujra.PasswordChar = '*';
            this.tb_jelszo_ujra.Size = new System.Drawing.Size(100, 20);
            this.tb_jelszo_ujra.TabIndex = 3;
            // 
            // tb_jelszo
            // 
            this.tb_jelszo.Location = new System.Drawing.Point(139, 84);
            this.tb_jelszo.Name = "tb_jelszo";
            this.tb_jelszo.PasswordChar = '*';
            this.tb_jelszo.Size = new System.Drawing.Size(100, 20);
            this.tb_jelszo.TabIndex = 2;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(358, 29);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(181, 20);
            this.tb_email.TabIndex = 4;
            // 
            // btn_createdefault
            // 
            this.btn_createdefault.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_createdefault.Location = new System.Drawing.Point(456, 149);
            this.btn_createdefault.Name = "btn_createdefault";
            this.btn_createdefault.Size = new System.Drawing.Size(83, 23);
            this.btn_createdefault.TabIndex = 33;
            this.btn_createdefault.Text = "Create default";
            this.btn_createdefault.UseVisualStyleBackColor = true;
            this.btn_createdefault.Click += new System.EventHandler(this.btn_createdefault_Click);
            // 
            // btn_restore
            // 
            this.btn_restore.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_restore.Location = new System.Drawing.Point(456, 179);
            this.btn_restore.Name = "btn_restore";
            this.btn_restore.Size = new System.Drawing.Size(83, 23);
            this.btn_restore.TabIndex = 34;
            this.btn_restore.Text = "Restore";
            this.btn_restore.UseVisualStyleBackColor = true;
            this.btn_restore.Click += new System.EventHandler(this.btn_restore_Click);
            // 
            // btn_vissza
            // 
            this.btn_vissza.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_vissza.Location = new System.Drawing.Point(13, 186);
            this.btn_vissza.Name = "btn_vissza";
            this.btn_vissza.Size = new System.Drawing.Size(75, 23);
            this.btn_vissza.TabIndex = 35;
            this.btn_vissza.Text = "Vissza";
            this.btn_vissza.UseVisualStyleBackColor = true;
            this.btn_vissza.Click += new System.EventHandler(this.btn_vissza_Click);
            // 
            // Regisztracios_Form
            // 
            this.AcceptButton = this.btn_Regisztrálás;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 221);
            this.Controls.Add(this.btn_vissza);
            this.Controls.Add(this.btn_restore);
            this.Controls.Add(this.btn_createdefault);
            this.Controls.Add(this.tb_nev);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_telefon_1);
            this.Controls.Add(this.cb_telefon);
            this.Controls.Add(this.tb_telefon_3);
            this.Controls.Add(this.tb_cim);
            this.Controls.Add(this.btn_Regisztrálás);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_jelszo_ujra);
            this.Controls.Add(this.tb_jelszo);
            this.Controls.Add(this.tb_email);
            this.Name = "Regisztracios_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Regisztráció";
            this.Load += new System.EventHandler(this.Regisztracios_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_nev;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_telefon_1;
        private System.Windows.Forms.ComboBox cb_telefon;
        private System.Windows.Forms.TextBox tb_telefon_3;
        private System.Windows.Forms.TextBox tb_cim;
        private System.Windows.Forms.Button btn_Regisztrálás;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_jelszo_ujra;
        private System.Windows.Forms.TextBox tb_jelszo;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Button btn_createdefault;
        private System.Windows.Forms.Button btn_restore;
        private System.Windows.Forms.Button btn_vissza;
    }
}