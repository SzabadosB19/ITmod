
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 05/01/2018 16:51:40
-- Generated from EDMX file: c:\Users\Bence\Documents\Visual Studio 2013\Projects\Rent_A_Flat\Rent_A_Flat\Rent_A_Flat_Entity_Model.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Rent_A_Flat];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Felhasznaloes]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Felhasznaloes];
GO
IF OBJECT_ID(N'[dbo].[Ingatlans]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Ingatlans];
GO
IF OBJECT_ID(N'[dbo].[Foglalas]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Foglalas];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Felhasznaloes'
CREATE TABLE [dbo].[Felhasznaloes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Nev] nvarchar(50)  NULL,
    [Email] nvarchar(50)  NULL,
    [Cim] nvarchar(50)  NULL,
    [Jelszo] nvarchar(50)  NULL,
    [Telefonszam] nvarchar(50)  NULL
);
GO

-- Creating table 'Ingatlans'
CREATE TABLE [dbo].[Ingatlans] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Cim] nvarchar(50)  NOT NULL,
    [Terulet] int  NOT NULL,
    [Szoba] int  NOT NULL,
    [Felszoba] int  NOT NULL,
    [Komfort] nvarchar(50)  NOT NULL,
    [Futes] nvarchar(50)  NOT NULL,
    [Furdo] int  NOT NULL,
    [Epites_eve] datetime  NOT NULL,
    [Parkolas] nvarchar(50)  NOT NULL,
    [Leiras] nvarchar(max)  NOT NULL,
    [Tulajdonos] nvarchar(50)  NOT NULL,
    [Ar] int  NOT NULL,
    [Kep] varbinary(max)  NULL,
    [Email] nvarchar(50)  NULL,
    [Tipus] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Foglalas'
CREATE TABLE [dbo].[Foglalas] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [IngatlanID] int  NOT NULL,
    [foglalasStart] datetime  NOT NULL,
    [foglalasEnd] datetime  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Felhasznaloes'
ALTER TABLE [dbo].[Felhasznaloes]
ADD CONSTRAINT [PK_Felhasznaloes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Ingatlans'
ALTER TABLE [dbo].[Ingatlans]
ADD CONSTRAINT [PK_Ingatlans]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Foglalas'
ALTER TABLE [dbo].[Foglalas]
ADD CONSTRAINT [PK_Foglalas]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------