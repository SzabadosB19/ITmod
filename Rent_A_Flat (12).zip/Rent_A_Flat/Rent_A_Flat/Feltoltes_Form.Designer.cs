﻿namespace Rent_A_Flat
{
    partial class Feltoltes_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rb_lakas = new System.Windows.Forms.RadioButton();
            this.rb_haz = new System.Windows.Forms.RadioButton();
            this.tb_cim = new System.Windows.Forms.TextBox();
            this.rtb_leiras = new System.Windows.Forms.RichTextBox();
            this.tb_terulet = new System.Windows.Forms.TextBox();
            this.tb_szobak = new System.Windows.Forms.TextBox();
            this.tb_felszoba = new System.Windows.Forms.TextBox();
            this.tb_futes = new System.Windows.Forms.TextBox();
            this.tb_furdo = new System.Windows.Forms.TextBox();
            this.label_cim = new System.Windows.Forms.Label();
            this.label_terulet = new System.Windows.Forms.Label();
            this.label_szobakszama = new System.Windows.Forms.Label();
            this.label_felszoba = new System.Windows.Forms.Label();
            this.label_komfort = new System.Windows.Forms.Label();
            this.label_futes = new System.Windows.Forms.Label();
            this.label_furdo = new System.Windows.Forms.Label();
            this.label_epiteseve = new System.Windows.Forms.Label();
            this.label_parkolas = new System.Windows.Forms.Label();
            this.label_leiras = new System.Windows.Forms.Label();
            this.dtp_epiteseve = new System.Windows.Forms.DateTimePicker();
            this.label_emelet = new System.Windows.Forms.Label();
            this.label_epuletszint = new System.Windows.Forms.Label();
            this.label_kert = new System.Windows.Forms.Label();
            this.label_emeletszama = new System.Windows.Forms.Label();
            this.tb_emelet = new System.Windows.Forms.TextBox();
            this.tb_epuletszint = new System.Windows.Forms.TextBox();
            this.tb_kert = new System.Windows.Forms.TextBox();
            this.tb_emeletekszama = new System.Windows.Forms.TextBox();
            this.btn_mentes = new System.Windows.Forms.Button();
            this.label_tulajdonos = new System.Windows.Forms.Label();
            this.tb_tulajdonos = new System.Windows.Forms.TextBox();
            this.tb_ar = new System.Windows.Forms.TextBox();
            this.label_ar = new System.Windows.Forms.Label();
            this.label_m2 = new System.Windows.Forms.Label();
            this.cb_komfort = new System.Windows.Forms.ComboBox();
            this.cb_parkolas = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnTalloz = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_vissza = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // rb_lakas
            // 
            this.rb_lakas.AutoSize = true;
            this.rb_lakas.Checked = true;
            this.rb_lakas.Location = new System.Drawing.Point(134, 29);
            this.rb_lakas.Margin = new System.Windows.Forms.Padding(4);
            this.rb_lakas.Name = "rb_lakas";
            this.rb_lakas.Size = new System.Drawing.Size(69, 23);
            this.rb_lakas.TabIndex = 50;
            this.rb_lakas.TabStop = true;
            this.rb_lakas.Text = "Lakás";
            this.rb_lakas.UseVisualStyleBackColor = true;
            // 
            // rb_haz
            // 
            this.rb_haz.AutoSize = true;
            this.rb_haz.Location = new System.Drawing.Point(298, 29);
            this.rb_haz.Margin = new System.Windows.Forms.Padding(4);
            this.rb_haz.Name = "rb_haz";
            this.rb_haz.Size = new System.Drawing.Size(53, 23);
            this.rb_haz.TabIndex = 1;
            this.rb_haz.Text = "Ház";
            this.rb_haz.UseVisualStyleBackColor = true;
            this.rb_haz.CheckedChanged += new System.EventHandler(this.rb_haz_CheckedChanged_1);
            // 
            // tb_cim
            // 
            this.tb_cim.Location = new System.Drawing.Point(134, 63);
            this.tb_cim.Margin = new System.Windows.Forms.Padding(4);
            this.tb_cim.Name = "tb_cim";
            this.tb_cim.Size = new System.Drawing.Size(217, 26);
            this.tb_cim.TabIndex = 0;
            // 
            // rtb_leiras
            // 
            this.rtb_leiras.Location = new System.Drawing.Point(201, 525);
            this.rtb_leiras.Margin = new System.Windows.Forms.Padding(4);
            this.rtb_leiras.Name = "rtb_leiras";
            this.rtb_leiras.Size = new System.Drawing.Size(359, 121);
            this.rtb_leiras.TabIndex = 9;
            this.rtb_leiras.Text = "";
            // 
            // tb_terulet
            // 
            this.tb_terulet.Location = new System.Drawing.Point(134, 101);
            this.tb_terulet.Margin = new System.Windows.Forms.Padding(4);
            this.tb_terulet.Name = "tb_terulet";
            this.tb_terulet.Size = new System.Drawing.Size(217, 26);
            this.tb_terulet.TabIndex = 1;
            // 
            // tb_szobak
            // 
            this.tb_szobak.Location = new System.Drawing.Point(134, 139);
            this.tb_szobak.Margin = new System.Windows.Forms.Padding(4);
            this.tb_szobak.Name = "tb_szobak";
            this.tb_szobak.Size = new System.Drawing.Size(217, 26);
            this.tb_szobak.TabIndex = 2;
            // 
            // tb_felszoba
            // 
            this.tb_felszoba.Location = new System.Drawing.Point(134, 177);
            this.tb_felszoba.Margin = new System.Windows.Forms.Padding(4);
            this.tb_felszoba.Name = "tb_felszoba";
            this.tb_felszoba.Size = new System.Drawing.Size(217, 26);
            this.tb_felszoba.TabIndex = 3;
            // 
            // tb_futes
            // 
            this.tb_futes.Location = new System.Drawing.Point(134, 253);
            this.tb_futes.Margin = new System.Windows.Forms.Padding(4);
            this.tb_futes.Name = "tb_futes";
            this.tb_futes.Size = new System.Drawing.Size(217, 26);
            this.tb_futes.TabIndex = 5;
            // 
            // tb_furdo
            // 
            this.tb_furdo.Location = new System.Drawing.Point(134, 291);
            this.tb_furdo.Margin = new System.Windows.Forms.Padding(4);
            this.tb_furdo.Name = "tb_furdo";
            this.tb_furdo.Size = new System.Drawing.Size(217, 26);
            this.tb_furdo.TabIndex = 6;
            // 
            // label_cim
            // 
            this.label_cim.AutoSize = true;
            this.label_cim.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_cim.Location = new System.Drawing.Point(86, 67);
            this.label_cim.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_cim.Name = "label_cim";
            this.label_cim.Size = new System.Drawing.Size(36, 19);
            this.label_cim.TabIndex = 20;
            this.label_cim.Text = "Cím";
            // 
            // label_terulet
            // 
            this.label_terulet.AutoSize = true;
            this.label_terulet.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_terulet.Location = new System.Drawing.Point(69, 104);
            this.label_terulet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_terulet.Name = "label_terulet";
            this.label_terulet.Size = new System.Drawing.Size(57, 19);
            this.label_terulet.TabIndex = 21;
            this.label_terulet.Text = "Terület";
            // 
            // label_szobakszama
            // 
            this.label_szobakszama.AutoSize = true;
            this.label_szobakszama.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_szobakszama.Location = new System.Drawing.Point(24, 142);
            this.label_szobakszama.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_szobakszama.Name = "label_szobakszama";
            this.label_szobakszama.Size = new System.Drawing.Size(102, 19);
            this.label_szobakszama.TabIndex = 22;
            this.label_szobakszama.Text = "Szobák száma";
            // 
            // label_felszoba
            // 
            this.label_felszoba.AutoSize = true;
            this.label_felszoba.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_felszoba.Location = new System.Drawing.Point(5, 184);
            this.label_felszoba.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_felszoba.Name = "label_felszoba";
            this.label_felszoba.Size = new System.Drawing.Size(121, 19);
            this.label_felszoba.TabIndex = 23;
            this.label_felszoba.Text = "Félszobák száma";
            // 
            // label_komfort
            // 
            this.label_komfort.AutoSize = true;
            this.label_komfort.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_komfort.Location = new System.Drawing.Point(61, 216);
            this.label_komfort.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_komfort.Name = "label_komfort";
            this.label_komfort.Size = new System.Drawing.Size(65, 19);
            this.label_komfort.TabIndex = 24;
            this.label_komfort.Text = "Komfort";
            // 
            // label_futes
            // 
            this.label_futes.AutoSize = true;
            this.label_futes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_futes.Location = new System.Drawing.Point(80, 256);
            this.label_futes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_futes.Name = "label_futes";
            this.label_futes.Size = new System.Drawing.Size(46, 19);
            this.label_futes.TabIndex = 25;
            this.label_futes.Text = "Fűtés";
            // 
            // label_furdo
            // 
            this.label_furdo.AutoSize = true;
            this.label_furdo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_furdo.Location = new System.Drawing.Point(78, 294);
            this.label_furdo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_furdo.Name = "label_furdo";
            this.label_furdo.Size = new System.Drawing.Size(48, 19);
            this.label_furdo.TabIndex = 26;
            this.label_furdo.Text = "Fürdő";
            // 
            // label_epiteseve
            // 
            this.label_epiteseve.AutoSize = true;
            this.label_epiteseve.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_epiteseve.Location = new System.Drawing.Point(47, 335);
            this.label_epiteseve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_epiteseve.Name = "label_epiteseve";
            this.label_epiteseve.Size = new System.Drawing.Size(79, 19);
            this.label_epiteseve.TabIndex = 27;
            this.label_epiteseve.Text = "Építés éve";
            // 
            // label_parkolas
            // 
            this.label_parkolas.AutoSize = true;
            this.label_parkolas.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_parkolas.Location = new System.Drawing.Point(58, 375);
            this.label_parkolas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_parkolas.Name = "label_parkolas";
            this.label_parkolas.Size = new System.Drawing.Size(68, 19);
            this.label_parkolas.TabIndex = 28;
            this.label_parkolas.Text = "Parkolás";
            // 
            // label_leiras
            // 
            this.label_leiras.AutoSize = true;
            this.label_leiras.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_leiras.Location = new System.Drawing.Point(141, 525);
            this.label_leiras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_leiras.Name = "label_leiras";
            this.label_leiras.Size = new System.Drawing.Size(52, 19);
            this.label_leiras.TabIndex = 29;
            this.label_leiras.Text = "Leírás";
            // 
            // dtp_epiteseve
            // 
            this.dtp_epiteseve.Location = new System.Drawing.Point(134, 329);
            this.dtp_epiteseve.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_epiteseve.MaxDate = new System.DateTime(2019, 12, 25, 23, 59, 59, 0);
            this.dtp_epiteseve.Name = "dtp_epiteseve";
            this.dtp_epiteseve.Size = new System.Drawing.Size(217, 26);
            this.dtp_epiteseve.TabIndex = 7;
            this.dtp_epiteseve.Value = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            // 
            // label_emelet
            // 
            this.label_emelet.AutoSize = true;
            this.label_emelet.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_emelet.Location = new System.Drawing.Point(70, 418);
            this.label_emelet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_emelet.Name = "label_emelet";
            this.label_emelet.Size = new System.Drawing.Size(56, 19);
            this.label_emelet.TabIndex = 31;
            this.label_emelet.Text = "Emelet";
            // 
            // label_epuletszint
            // 
            this.label_epuletszint.AutoSize = true;
            this.label_epuletszint.Location = new System.Drawing.Point(130, 456);
            this.label_epuletszint.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_epuletszint.Name = "label_epuletszint";
            this.label_epuletszint.Size = new System.Drawing.Size(102, 19);
            this.label_epuletszint.TabIndex = 32;
            this.label_epuletszint.Text = "Épület szintjei";
            // 
            // label_kert
            // 
            this.label_kert.AutoSize = true;
            this.label_kert.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_kert.Location = new System.Drawing.Point(86, 418);
            this.label_kert.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_kert.Name = "label_kert";
            this.label_kert.Size = new System.Drawing.Size(40, 19);
            this.label_kert.TabIndex = 33;
            this.label_kert.Text = "Kert";
            this.label_kert.Visible = false;
            // 
            // label_emeletszama
            // 
            this.label_emeletszama.AutoSize = true;
            this.label_emeletszama.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_emeletszama.Location = new System.Drawing.Point(8, 455);
            this.label_emeletszama.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_emeletszama.Name = "label_emeletszama";
            this.label_emeletszama.Size = new System.Drawing.Size(118, 19);
            this.label_emeletszama.TabIndex = 34;
            this.label_emeletszama.Text = "Emeletek száma";
            this.label_emeletszama.Visible = false;
            // 
            // tb_emelet
            // 
            this.tb_emelet.Location = new System.Drawing.Point(134, 415);
            this.tb_emelet.Margin = new System.Windows.Forms.Padding(4);
            this.tb_emelet.Name = "tb_emelet";
            this.tb_emelet.Size = new System.Drawing.Size(217, 26);
            this.tb_emelet.TabIndex = 12;
            // 
            // tb_epuletszint
            // 
            this.tb_epuletszint.Location = new System.Drawing.Point(134, 452);
            this.tb_epuletszint.Margin = new System.Windows.Forms.Padding(4);
            this.tb_epuletszint.Name = "tb_epuletszint";
            this.tb_epuletszint.Size = new System.Drawing.Size(217, 26);
            this.tb_epuletszint.TabIndex = 13;
            // 
            // tb_kert
            // 
            this.tb_kert.Location = new System.Drawing.Point(134, 414);
            this.tb_kert.Margin = new System.Windows.Forms.Padding(4);
            this.tb_kert.Name = "tb_kert";
            this.tb_kert.Size = new System.Drawing.Size(217, 26);
            this.tb_kert.TabIndex = 10;
            this.tb_kert.Visible = false;
            this.tb_kert.WordWrap = false;
            // 
            // tb_emeletekszama
            // 
            this.tb_emeletekszama.Location = new System.Drawing.Point(134, 452);
            this.tb_emeletekszama.Margin = new System.Windows.Forms.Padding(4);
            this.tb_emeletekszama.Name = "tb_emeletekszama";
            this.tb_emeletekszama.Size = new System.Drawing.Size(217, 26);
            this.tb_emeletekszama.TabIndex = 11;
            this.tb_emeletekszama.Visible = false;
            this.tb_emeletekszama.WordWrap = false;
            // 
            // btn_mentes
            // 
            this.btn_mentes.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_mentes.Image = global::Rent_A_Flat.Properties.Resources.save_icon;
            this.btn_mentes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mentes.Location = new System.Drawing.Point(609, 526);
            this.btn_mentes.Margin = new System.Windows.Forms.Padding(4);
            this.btn_mentes.Name = "btn_mentes";
            this.btn_mentes.Size = new System.Drawing.Size(110, 63);
            this.btn_mentes.TabIndex = 15;
            this.btn_mentes.Text = "Mentés";
            this.btn_mentes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_mentes.UseVisualStyleBackColor = true;
            this.btn_mentes.Click += new System.EventHandler(this.btn_mentes_Click);
            // 
            // label_tulajdonos
            // 
            this.label_tulajdonos.AutoSize = true;
            this.label_tulajdonos.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_tulajdonos.Location = new System.Drawing.Point(41, 489);
            this.label_tulajdonos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_tulajdonos.Name = "label_tulajdonos";
            this.label_tulajdonos.Size = new System.Drawing.Size(81, 19);
            this.label_tulajdonos.TabIndex = 40;
            this.label_tulajdonos.Text = "Tulajdonos";
            // 
            // tb_tulajdonos
            // 
            this.tb_tulajdonos.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tb_tulajdonos.Location = new System.Drawing.Point(134, 489);
            this.tb_tulajdonos.Margin = new System.Windows.Forms.Padding(4);
            this.tb_tulajdonos.Name = "tb_tulajdonos";
            this.tb_tulajdonos.ReadOnly = true;
            this.tb_tulajdonos.Size = new System.Drawing.Size(217, 26);
            this.tb_tulajdonos.TabIndex = 41;
            this.tb_tulajdonos.WordWrap = false;
            // 
            // tb_ar
            // 
            this.tb_ar.Location = new System.Drawing.Point(445, 368);
            this.tb_ar.Margin = new System.Windows.Forms.Padding(4);
            this.tb_ar.Name = "tb_ar";
            this.tb_ar.Size = new System.Drawing.Size(217, 26);
            this.tb_ar.TabIndex = 51;
            // 
            // label_ar
            // 
            this.label_ar.AutoSize = true;
            this.label_ar.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_ar.Location = new System.Drawing.Point(406, 372);
            this.label_ar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ar.Name = "label_ar";
            this.label_ar.Size = new System.Drawing.Size(31, 22);
            this.label_ar.TabIndex = 52;
            this.label_ar.Text = "Ár";
            // 
            // label_m2
            // 
            this.label_m2.AutoSize = true;
            this.label_m2.Location = new System.Drawing.Point(359, 104);
            this.label_m2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_m2.Name = "label_m2";
            this.label_m2.Size = new System.Drawing.Size(29, 19);
            this.label_m2.TabIndex = 53;
            this.label_m2.Text = "m2";
            // 
            // cb_komfort
            // 
            this.cb_komfort.FormattingEnabled = true;
            this.cb_komfort.Items.AddRange(new object[] {
            "összkomfortos",
            "duplakomfortos"});
            this.cb_komfort.Location = new System.Drawing.Point(134, 213);
            this.cb_komfort.Margin = new System.Windows.Forms.Padding(4);
            this.cb_komfort.Name = "cb_komfort";
            this.cb_komfort.Size = new System.Drawing.Size(217, 27);
            this.cb_komfort.TabIndex = 55;
            // 
            // cb_parkolas
            // 
            this.cb_parkolas.FormattingEnabled = true;
            this.cb_parkolas.Items.AddRange(new object[] {
            "közterületen - ingyenes",
            "közterületen - fizetős",
            "belső udvarban",
            "teremgarázsban",
            "garázsban"});
            this.cb_parkolas.Location = new System.Drawing.Point(134, 367);
            this.cb_parkolas.Margin = new System.Windows.Forms.Padding(4);
            this.cb_parkolas.Name = "cb_parkolas";
            this.cb_parkolas.Size = new System.Drawing.Size(217, 27);
            this.cb_parkolas.TabIndex = 56;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(670, 374);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 19);
            this.label2.TabIndex = 57;
            this.label2.Text = "/éjszaka";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(445, 85);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(248, 216);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 58;
            this.pictureBox1.TabStop = false;
            // 
            // btnTalloz
            // 
            this.btnTalloz.Location = new System.Drawing.Point(618, 307);
            this.btnTalloz.Name = "btnTalloz";
            this.btnTalloz.Size = new System.Drawing.Size(75, 23);
            this.btnTalloz.TabIndex = 59;
            this.btnTalloz.Text = "Tallózás";
            this.btnTalloz.UseVisualStyleBackColor = true;
            this.btnTalloz.Click += new System.EventHandler(this.btnTalloz_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(28, 526);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 60;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tb_email
            // 
            this.tb_email.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tb_email.Location = new System.Drawing.Point(364, 489);
            this.tb_email.Margin = new System.Windows.Forms.Padding(4);
            this.tb_email.Name = "tb_email";
            this.tb_email.ReadOnly = true;
            this.tb_email.Size = new System.Drawing.Size(196, 26);
            this.tb_email.TabIndex = 61;
            this.tb_email.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(441, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 19);
            this.label1.TabIndex = 62;
            this.label1.Text = "Kép feltöltése";
            // 
            // btn_vissza
            // 
            this.btn_vissza.Location = new System.Drawing.Point(658, 623);
            this.btn_vissza.Name = "btn_vissza";
            this.btn_vissza.Size = new System.Drawing.Size(75, 23);
            this.btn_vissza.TabIndex = 63;
            this.btn_vissza.Text = "Vissza";
            this.btn_vissza.UseVisualStyleBackColor = true;
            this.btn_vissza.Click += new System.EventHandler(this.btn_vissza_Click);
            // 
            // Feltoltes_Form
            // 
            this.AcceptButton = this.btn_mentes;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(762, 660);
            this.Controls.Add(this.btn_vissza);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_email);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnTalloz);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_parkolas);
            this.Controls.Add(this.cb_komfort);
            this.Controls.Add(this.label_m2);
            this.Controls.Add(this.label_ar);
            this.Controls.Add(this.tb_ar);
            this.Controls.Add(this.tb_tulajdonos);
            this.Controls.Add(this.label_tulajdonos);
            this.Controls.Add(this.btn_mentes);
            this.Controls.Add(this.tb_emeletekszama);
            this.Controls.Add(this.tb_kert);
            this.Controls.Add(this.tb_epuletszint);
            this.Controls.Add(this.tb_emelet);
            this.Controls.Add(this.label_emeletszama);
            this.Controls.Add(this.label_kert);
            this.Controls.Add(this.label_epuletszint);
            this.Controls.Add(this.label_emelet);
            this.Controls.Add(this.dtp_epiteseve);
            this.Controls.Add(this.label_leiras);
            this.Controls.Add(this.label_parkolas);
            this.Controls.Add(this.label_epiteseve);
            this.Controls.Add(this.label_furdo);
            this.Controls.Add(this.label_futes);
            this.Controls.Add(this.label_komfort);
            this.Controls.Add(this.label_felszoba);
            this.Controls.Add(this.label_szobakszama);
            this.Controls.Add(this.label_terulet);
            this.Controls.Add(this.label_cim);
            this.Controls.Add(this.tb_furdo);
            this.Controls.Add(this.tb_futes);
            this.Controls.Add(this.tb_felszoba);
            this.Controls.Add(this.tb_szobak);
            this.Controls.Add(this.tb_terulet);
            this.Controls.Add(this.rtb_leiras);
            this.Controls.Add(this.tb_cim);
            this.Controls.Add(this.rb_haz);
            this.Controls.Add(this.rb_lakas);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Feltoltes_Form";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Feltoltes_Form";
            this.Load += new System.EventHandler(this.Feltoltes_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rb_lakas;
        private System.Windows.Forms.RadioButton rb_haz;
        private System.Windows.Forms.TextBox tb_cim;
        private System.Windows.Forms.RichTextBox rtb_leiras;
        private System.Windows.Forms.TextBox tb_terulet;
        private System.Windows.Forms.TextBox tb_szobak;
        private System.Windows.Forms.TextBox tb_felszoba;
        private System.Windows.Forms.TextBox tb_futes;
        private System.Windows.Forms.TextBox tb_furdo;
        private System.Windows.Forms.Label label_cim;
        private System.Windows.Forms.Label label_terulet;
        private System.Windows.Forms.Label label_szobakszama;
        private System.Windows.Forms.Label label_felszoba;
        private System.Windows.Forms.Label label_komfort;
        private System.Windows.Forms.Label label_futes;
        private System.Windows.Forms.Label label_furdo;
        private System.Windows.Forms.Label label_epiteseve;
        private System.Windows.Forms.Label label_parkolas;
        private System.Windows.Forms.Label label_leiras;
        private System.Windows.Forms.DateTimePicker dtp_epiteseve;
        private System.Windows.Forms.Label label_emelet;
        private System.Windows.Forms.Label label_epuletszint;
        private System.Windows.Forms.Label label_kert;
        private System.Windows.Forms.Label label_emeletszama;
        private System.Windows.Forms.TextBox tb_emelet;
        private System.Windows.Forms.TextBox tb_epuletszint;
        private System.Windows.Forms.TextBox tb_kert;
        private System.Windows.Forms.TextBox tb_emeletekszama;
        private System.Windows.Forms.Button btn_mentes;
        private System.Windows.Forms.Label label_tulajdonos;
        private System.Windows.Forms.TextBox tb_tulajdonos;
        private System.Windows.Forms.TextBox tb_ar;
        private System.Windows.Forms.Label label_ar;
        private System.Windows.Forms.Label label_m2;
        private System.Windows.Forms.ComboBox cb_komfort;
        private System.Windows.Forms.ComboBox cb_parkolas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnTalloz;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_vissza;
    }
}