﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rent_A_Flat
{
    public partial class Foglalas_Form : Form
    {
        String foglalt_datumok;

        public String Foglalt_datumok
        {
            get { return foglalt_datumok; }
            set { foglalt_datumok = value; }
        }

        public Foglalas_Form()
        {
            InitializeComponent();
        }

        int currentIngatlanID;

        public int CurrentIngatlanID
        {
            get { return currentIngatlanID; }
            set { currentIngatlanID = value; }
        }

        List<IRange<DateTime>> eddigiFoglalasok=new List<IRange<DateTime>>();

        private void btn_mentes_Click(object sender, EventArgs e)
        {
            if (dtp_start.Value<=DateTime.Today)
            {
                MessageBox.Show("Mára már nem adható foglalás");
            }

            if (dtp_end.Value <= dtp_start.Value)
            {
                MessageBox.Show("Minimum 1 napot foglalni kell");

            }
            
            DateRange foglalniKivant = new DateRange(dtp_start.Value, dtp_end.Value);
            
            // ellenorzi, hgoy a kiválasztott dateRange ütközik-e az eddigi foglalásokkal
            bool utkozes = false;
            foreach (var item in eddigiFoglalasok)
            {
                if (item.Includes(foglalniKivant))
                {
                    //todo megjeleniteni az utkozo dateranget
                    utkozes = true;
                    MessageBox.Show("Nem lehet hozzáadni, mert ütközik korábbi foglalással: " + item.ToString());
                    break;
                }
            }

            if (!utkozes)
            {

                using (Rent_A_FlatEntities context = new Rent_A_FlatEntities())
                {

                    Foglalas foglal = new Foglalas(currentIngatlanID, dtp_start.Value, dtp_end.Value);
                    context.Foglalas.Add(foglal);

                    context.SaveChanges();

                    MessageBox.Show("Sikeres foglalás");
                    this.Close();
                }
            }
            //todo reloadolni a formot
            InitializeComponent();

        }



        private void Foglalas_Form_Load(object sender, EventArgs e)
        {
            
            
            Rent_A_FlatEntities raf = new Rent_A_FlatEntities();
            var results = raf.Foglalas.Where(a => a.IngatlanID == this.currentIngatlanID);
            if (results!=null)
            {
                foreach (var item in results)
                {
                        eddigiFoglalasok.Add(new DateRange(item.foglalasStart, item.foglalasEnd));
                        lb_eddigiFoglalasok.Items.Add(new DateRange(item.foglalasStart, item.foglalasEnd));
                        foglalt_datumok += "\n" + item.foglalasStart.ToString("yyyy, mm, dd") + " - " + item.foglalasEnd.ToString("yyyy, mm, dd");

                }
            }
            //lb_eddigiFoglalasok.Items.Add(eddigiFoglalasok);

            
            

        }

       /* private void lb_eddigiFoglalasok_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DateTime start = (lb_eddigiFoglalasok.SelectedItem as Foglalas).foglalasStart;
            //DateTime end = (lb_eddigiFoglalasok.SelectedItem as Foglalas).foglalasEnd;
            //cal_foglalas.TitleBackColor = Color.Red;
        }
        */
        
    } 
}
