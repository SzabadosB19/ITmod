﻿namespace Rent_A_Flat
{
    partial class Foglalas_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_start = new System.Windows.Forms.DateTimePicker();
            this.dtp_end = new System.Windows.Forms.DateTimePicker();
            this.btn_mentes = new System.Windows.Forms.Button();
            this.lb_eddigiFoglalasok = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // dtp_start
            // 
            this.dtp_start.Location = new System.Drawing.Point(35, 39);
            this.dtp_start.Name = "dtp_start";
            this.dtp_start.Size = new System.Drawing.Size(200, 20);
            this.dtp_start.TabIndex = 0;
            // 
            // dtp_end
            // 
            this.dtp_end.Location = new System.Drawing.Point(35, 80);
            this.dtp_end.Name = "dtp_end";
            this.dtp_end.Size = new System.Drawing.Size(200, 20);
            this.dtp_end.TabIndex = 1;
            // 
            // btn_mentes
            // 
            this.btn_mentes.Location = new System.Drawing.Point(35, 300);
            this.btn_mentes.Name = "btn_mentes";
            this.btn_mentes.Size = new System.Drawing.Size(200, 38);
            this.btn_mentes.TabIndex = 2;
            this.btn_mentes.Text = "Mentés";
            this.btn_mentes.UseVisualStyleBackColor = true;
            this.btn_mentes.Click += new System.EventHandler(this.btn_mentes_Click);
            // 
            // lb_eddigiFoglalasok
            // 
            this.lb_eddigiFoglalasok.FormattingEnabled = true;
            this.lb_eddigiFoglalasok.Location = new System.Drawing.Point(35, 118);
            this.lb_eddigiFoglalasok.Name = "lb_eddigiFoglalasok";
            this.lb_eddigiFoglalasok.Size = new System.Drawing.Size(200, 160);
            this.lb_eddigiFoglalasok.TabIndex = 3;
            // 
            // Foglalas_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 362);
            this.Controls.Add(this.lb_eddigiFoglalasok);
            this.Controls.Add(this.btn_mentes);
            this.Controls.Add(this.dtp_end);
            this.Controls.Add(this.dtp_start);
            this.Name = "Foglalas_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Foglalás";
            this.Load += new System.EventHandler(this.Foglalas_Form_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_start;
        private System.Windows.Forms.DateTimePicker dtp_end;
        private System.Windows.Forms.Button btn_mentes;
        private System.Windows.Forms.ListBox lb_eddigiFoglalasok;
    }
}