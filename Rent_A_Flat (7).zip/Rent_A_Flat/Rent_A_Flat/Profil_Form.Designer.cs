﻿namespace Rent_A_Flat
{
    partial class Profil_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_nev = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_cim = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_jelszo_ujra = new System.Windows.Forms.TextBox();
            this.tb_jelszo = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.btn_modosit = new System.Windows.Forms.Button();
            this.tb_telefon = new System.Windows.Forms.TextBox();
            this.btn_visszavon = new System.Windows.Forms.Button();
            this.lb_Felhasznalo = new System.Windows.Forms.Label();
            this.label_ingatlan = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btn_Mentes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_nev
            // 
            this.tb_nev.Location = new System.Drawing.Point(148, 52);
            this.tb_nev.Name = "tb_nev";
            this.tb_nev.ReadOnly = true;
            this.tb_nev.Size = new System.Drawing.Size(100, 20);
            this.tb_nev.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(110, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 46;
            this.label1.Text = "Név";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(290, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 15);
            this.label6.TabIndex = 45;
            this.label6.Text = "Telefonszám";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(331, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 15);
            this.label5.TabIndex = 44;
            this.label5.Text = "Cím";
            // 
            // tb_cim
            // 
            this.tb_cim.Location = new System.Drawing.Point(367, 100);
            this.tb_cim.Name = "tb_cim";
            this.tb_cim.ReadOnly = true;
            this.tb_cim.Size = new System.Drawing.Size(181, 20);
            this.tb_cim.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(28, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 15);
            this.label3.TabIndex = 43;
            this.label3.Text = "Jelszó megerősítése";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(95, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 42;
            this.label2.Text = "Jelszó";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(301, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 15);
            this.label4.TabIndex = 41;
            this.label4.Text = "E-mail cím";
            // 
            // tb_jelszo_ujra
            // 
            this.tb_jelszo_ujra.Location = new System.Drawing.Point(148, 152);
            this.tb_jelszo_ujra.Name = "tb_jelszo_ujra";
            this.tb_jelszo_ujra.PasswordChar = '*';
            this.tb_jelszo_ujra.ReadOnly = true;
            this.tb_jelszo_ujra.Size = new System.Drawing.Size(100, 20);
            this.tb_jelszo_ujra.TabIndex = 35;
            // 
            // tb_jelszo
            // 
            this.tb_jelszo.Location = new System.Drawing.Point(148, 107);
            this.tb_jelszo.Name = "tb_jelszo";
            this.tb_jelszo.PasswordChar = '*';
            this.tb_jelszo.ReadOnly = true;
            this.tb_jelszo.Size = new System.Drawing.Size(100, 20);
            this.tb_jelszo.TabIndex = 34;
            // 
            // tb_email
            // 
            this.tb_email.Location = new System.Drawing.Point(367, 52);
            this.tb_email.Name = "tb_email";
            this.tb_email.ReadOnly = true;
            this.tb_email.Size = new System.Drawing.Size(181, 20);
            this.tb_email.TabIndex = 36;
            // 
            // btn_modosit
            // 
            this.btn_modosit.Location = new System.Drawing.Point(367, 196);
            this.btn_modosit.Name = "btn_modosit";
            this.btn_modosit.Size = new System.Drawing.Size(75, 23);
            this.btn_modosit.TabIndex = 47;
            this.btn_modosit.Text = "Módosítás";
            this.btn_modosit.UseVisualStyleBackColor = true;
            this.btn_modosit.Click += new System.EventHandler(this.btn_modosit_Click);
            // 
            // tb_telefon
            // 
            this.tb_telefon.Location = new System.Drawing.Point(367, 147);
            this.tb_telefon.Name = "tb_telefon";
            this.tb_telefon.ReadOnly = true;
            this.tb_telefon.Size = new System.Drawing.Size(181, 20);
            this.tb_telefon.TabIndex = 49;
            // 
            // btn_visszavon
            // 
            this.btn_visszavon.Location = new System.Drawing.Point(367, 196);
            this.btn_visszavon.Name = "btn_visszavon";
            this.btn_visszavon.Size = new System.Drawing.Size(75, 23);
            this.btn_visszavon.TabIndex = 50;
            this.btn_visszavon.Text = "Visszavonás";
            this.btn_visszavon.UseVisualStyleBackColor = true;
            this.btn_visszavon.Click += new System.EventHandler(this.btn_visszavon_Click);
            // 
            // lb_Felhasznalo
            // 
            this.lb_Felhasznalo.AutoSize = true;
            this.lb_Felhasznalo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_Felhasznalo.Location = new System.Drawing.Point(27, 19);
            this.lb_Felhasznalo.Name = "lb_Felhasznalo";
            this.lb_Felhasznalo.Size = new System.Drawing.Size(141, 19);
            this.lb_Felhasznalo.TabIndex = 51;
            this.lb_Felhasznalo.Text = "Felhasználói adatok";
            // 
            // label_ingatlan
            // 
            this.label_ingatlan.AutoSize = true;
            this.label_ingatlan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_ingatlan.Location = new System.Drawing.Point(27, 226);
            this.label_ingatlan.Name = "label_ingatlan";
            this.label_ingatlan.Size = new System.Drawing.Size(117, 19);
            this.label_ingatlan.TabIndex = 52;
            this.label_ingatlan.Text = "Saját ingatlanok";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(98, 258);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(150, 134);
            this.listBox1.TabIndex = 53;
            // 
            // btn_Mentes
            // 
            this.btn_Mentes.Location = new System.Drawing.Point(449, 195);
            this.btn_Mentes.Name = "btn_Mentes";
            this.btn_Mentes.Size = new System.Drawing.Size(75, 23);
            this.btn_Mentes.TabIndex = 54;
            this.btn_Mentes.Text = "Mentés";
            this.btn_Mentes.UseVisualStyleBackColor = true;
            this.btn_Mentes.Click += new System.EventHandler(this.btn_Mentes_Click);
            // 
            // Profil_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 402);
            this.Controls.Add(this.btn_Mentes);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label_ingatlan);
            this.Controls.Add(this.lb_Felhasznalo);
            this.Controls.Add(this.btn_visszavon);
            this.Controls.Add(this.tb_telefon);
            this.Controls.Add(this.btn_modosit);
            this.Controls.Add(this.tb_nev);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_cim);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_jelszo_ujra);
            this.Controls.Add(this.tb_jelszo);
            this.Controls.Add(this.tb_email);
            this.Name = "Profil_Form";
            this.Text = "Profil_Form";
            this.Load += new System.EventHandler(this.Profil_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_nev;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_cim;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_jelszo_ujra;
        private System.Windows.Forms.TextBox tb_jelszo;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Button btn_modosit;
        private System.Windows.Forms.TextBox tb_telefon;
        private System.Windows.Forms.Button btn_visszavon;
        private System.Windows.Forms.Label lb_Felhasznalo;
        private System.Windows.Forms.Label label_ingatlan;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btn_Mentes;
    }
}