﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Rent_A_Flat
{
    public partial class Feltoltes_Form : Form
    {
        Felhasznalo tulajdonosFelhasznalo;

        public Felhasznalo TulajdonosFelhasznalo
        {
            get { return tulajdonosFelhasznalo; }
            set { tulajdonosFelhasznalo = value; }
        }
        public Feltoltes_Form()
        {
            InitializeComponent();
            
        }

       

        private void rb_haz_CheckedChanged_1(object sender, EventArgs e)
        {
            label_emelet.Visible = !label_emelet.Visible;
            label_epuletszint.Visible = !label_epuletszint.Visible;
            tb_emelet.Visible = !tb_emelet.Visible;
            tb_epuletszint.Visible = !tb_epuletszint.Visible;

            label_kert.Visible = !label_kert.Visible;
            label_emeletszama.Visible = !label_emeletszama.Visible;
            tb_kert.Visible = !tb_kert.Visible;
            tb_emeletekszama.Visible = !tb_emeletekszama.Visible;
        }

        
        private byte[] ConvertFiletoByte(string sPath)
        {
            byte[] data = null;
            FileInfo fInfo = new FileInfo(sPath);
            long numBytes = fInfo.Length;
            FileStream fStream = new FileStream(sPath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fStream);
            data = br.ReadBytes((int)numBytes);
            return data;
        }
        


        private void btn_mentes_Click(object sender, EventArgs e)
        {
            if (tb_cim.Text!="")
            {
                using (Rent_A_FlatEntities context = new Rent_A_FlatEntities())
                {

                    

                    byte[] picToUpload;

                    if (this.pictureBox1.ImageLocation!=null)
                    {
                        picToUpload = ConvertFiletoByte(this.pictureBox1.ImageLocation);
                    }
                    else
                    {
                        picToUpload = new byte[0];
                    }
                    /*Ingatlan ingatlan = new Ingatlan(tb_cim.Text, Convert.ToInt32(tb_terulet.Text), Convert.ToInt32(tb_szobak.Text),
                        Convert.ToInt32(tb_felszoba.Text), cb_komfort.Text, tb_futes.Text, Convert.ToInt32(tb_furdo.Text),
                        dtp_epiteseve.Value, cb_parkolas.Text, rtb_leiras.Text, tb_tulajdonos.Text, 
                        Convert.ToInt32(tb_ar.Text),ConvertFiletoByte(this.pictureBox1.ImageLocation), tb_email.Text);
                    */
                    String cim = this.tb_cim.Text == null ? "nincs megadva" : this.tb_cim.Text;
                    String terulet = this.tb_terulet.Text == null ? "nincs megadva" : this.tb_terulet.Text;
                    String szobak = this.tb_szobak.Text == null ? "nincs megadva" : this.tb_szobak.Text;
                    String felszoba = this.tb_felszoba.Text == null ? "nincs megadva" : this.tb_felszoba.Text;
                    String komfort = this.cb_komfort == null ? "nincs megadva" : this.cb_komfort.Text;
                    String futes = this.tb_futes == null ? "nincs megadva" : this.tb_futes.Text;
                    String furdo = this.tb_furdo.Text == null ? "nincs megadva" : this.tb_furdo.Text;
                    String parkolas = this.cb_parkolas == null ? "nincs megadva" : this.cb_parkolas.Text;
                    String leiras = this.rtb_leiras == null ? "nincs megadva" : this.rtb_leiras.Text;
                    String tulajdonos=this.tb_tulajdonos == null ? "nincs megadva" : this.tb_tulajdonos.Text;
                    String emailcim = this.tb_email == null ? "nincs megadva" : this.tb_email.Text;
                    String ar = this.tb_ar == null ? "nincs megadva" : this.tb_ar.Text;
                    

                    Ingatlan ingatlan = new Ingatlan(cim, Convert.ToInt32(terulet), Convert.ToInt32(szobak),
                        Convert.ToInt32(felszoba),komfort, futes, Convert.ToInt32(furdo),
                        dtp_epiteseve.Value, parkolas, leiras, tulajdonos,
                        Convert.ToInt32(ar), picToUpload, emailcim);
                    context.Ingatlans.Add(ingatlan);

                    try
                    {
                        context.SaveChanges();
                    }
                    catch (Exception ec)
                    {
                        Console.WriteLine(ec.Message);
                    }

                    DialogResult = DialogResult.OK;
                }
            }
        }

        private void Feltoltes_Form_Load(object sender, EventArgs e)
        {
            tb_tulajdonos.Text = tulajdonosFelhasznalo.ToString();
            tb_email.Text = tulajdonosFelhasznalo.Email;
            ToolTip tooltip1 = new ToolTip();
            tooltip1.ShowAlways = true;
            tooltip1.SetToolTip(tb_cim, "Például: 1111, Budapest, Példa utca 1.");

            ToolTip tooltip2 = new ToolTip();
            tooltip2.ShowAlways = true;
            tooltip2.SetToolTip(tb_terulet, "Adja meg hány négyzetméter az ingatlan");

            ToolTip tooltip3 = new ToolTip();
            tooltip3.ShowAlways = true;
            tooltip3.SetToolTip(tb_szobak, "Adja meg szobás az ingatlan");

            ToolTip tooltip4 = new ToolTip();
            tooltip4.ShowAlways = true;
            tooltip4.SetToolTip(tb_felszoba, "Adja meg hány félszoba tartozik az ingatlanhoz");

            ToolTip tooltip5 = new ToolTip();
            tooltip5.ShowAlways = true;
            tooltip5.SetToolTip(cb_komfort, "Adja meg az ingatlan komfortfokozatát");

            ToolTip tooltip6 = new ToolTip();
            tooltip6.ShowAlways = true;
            tooltip6.SetToolTip(tb_futes, "Adja meg a fűtés típusát");

            ToolTip tooltip7 = new ToolTip();
            tooltip7.ShowAlways = true;
            tooltip7.SetToolTip(cb_parkolas, "Adja meg a parkolási lehetőséget");
            
            ToolTip tooltip8 = new ToolTip();
            tooltip8.ShowAlways = true;
            tooltip8.SetToolTip(tb_emelet, "Adja meg hányadik emeleten van a lakás");

            ToolTip tooltip9 = new ToolTip();
            tooltip9.ShowAlways = true;
            tooltip9.SetToolTip(tb_emeletekszama, "Adja meg hány emeletes a ház, amelyben a lakás található");

            ToolTip tooltip10 = new ToolTip();
            tooltip10.ShowAlways = true;
            tooltip10.SetToolTip(tb_kert, "Adja meg hány négyzetméteres kert tartozik a házhoz");

            ToolTip tooltip11 = new ToolTip();
            tooltip11.ShowAlways = true;
            tooltip11.SetToolTip(tb_epuletszint, "Adja meg hány szintes a ház");

            ToolTip tooltip12 = new ToolTip();
            tooltip12.ShowAlways = true;
            tooltip12.SetToolTip(rtb_leiras, "Olyan információkat írjon le, amelyeket a fentieken kívűl fontosnak tart");

            ToolTip tooltip13 = new ToolTip();
            tooltip13.ShowAlways = true;
            tooltip13.SetToolTip(tb_furdo, "Adja meg hány fürdő van");

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
            try
            {
                System.Diagnostics.Process.Start("https://www.google.hu/maps/place/"+tb_cim.Text);
            }
            catch { }
        }

        private void btnTalloz_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Please select a photo.";
            ofd.Filter = "JPG|*.jpg|PNG|*.png";
            ofd.Multiselect = false;
            if (ofd.ShowDialog()==DialogResult.OK)
            {
                this.pictureBox1.ImageLocation = ofd.FileName;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tb_cim.Text = "1111, Budapest, Alma utca 11.";
            tb_terulet.Text = "55";
            tb_szobak.Text = "4";
            tb_felszoba.Text = "3";
            cb_komfort.Text = "duplakomfortos";
            tb_futes.Text = "cirko";
            tb_furdo.Text = "2";
            cb_parkolas.Text = "utcán - ingyenes";
            tb_ar.Text = "15000";
            rtb_leiras.Text = "blablalba";

        }

        

        
        

    }
}
