﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;
using System.Timers;


namespace Rent_A_Flat
{
    public partial class Foglalas_Form : Form
    {
        String foglalt_datumok;

        public String Foglalt_datumok
        {
            get { return foglalt_datumok; }
            set { foglalt_datumok = value; }
        }
        

        public Foglalas_Form()
        {
            InitializeComponent();
        }

        int currentIngatlanID;

        public int CurrentIngatlanID
        {
            get { return currentIngatlanID; }
            set { currentIngatlanID = value; }
        }

        List<IRange<DateTime>> eddigiFoglalasok=new List<IRange<DateTime>>();

        private void btn_mentes_Click(object sender, EventArgs e)
        {
            if (dtp_start.Value<=DateTime.Today)
            {
                MessageBox.Show("Mára már nem adható foglalás");
            }

            if (dtp_end.Value <= dtp_start.Value)
            {
                MessageBox.Show("Minimum 1 napot foglalni kell");

            }
            
            DateRange foglalniKivant = new DateRange(dtp_start.Value, dtp_end.Value);
            
            // ellenorzi, hgoy a kiválasztott dateRange ütközik-e az eddigi foglalásokkal
            bool utkozes = false;
            foreach (var item in eddigiFoglalasok)
            {
                if (item.Includes(foglalniKivant))
                {
                    //todo megjeleniteni az utkozo dateranget
                    utkozes = true;
                    MessageBox.Show("Nem lehet hozzáadni, mert ütközik korábbi foglalással: " + item.ToString());
                    break;
                }
            }

            if (!utkozes)
            {

                using (Rent_A_FlatEntities context = new Rent_A_FlatEntities())
                {

                    Foglalas foglal = new Foglalas(currentIngatlanID, dtp_start.Value, dtp_end.Value);
                    context.Foglalas.Add(foglal);

                    context.SaveChanges();

                    MessageBox.Show("Sikeres foglalás");
                    this.Close();
                }
            }
            //todo reloadolni a formot
            InitializeComponent();
        }


        private void Foglalas_Form_Load(object sender, EventArgs e)
        {
            Rent_A_FlatEntities raf = new Rent_A_FlatEntities();
            var results = raf.Foglalas.Where(a => a.IngatlanID == this.currentIngatlanID);
            if (results!=null)
            {
                foreach (var item in results)
                {
                        eddigiFoglalasok.Add(new DateRange(item.foglalasStart, item.foglalasEnd));
                        lb_eddigiFoglalasok.Items.Add(new DateRange(item.foglalasStart, item.foglalasEnd));
                        foglalt_datumok += "\n" + item.foglalasStart.ToString("yyyy, mm, dd") + " - " + item.foglalasEnd.ToString("yyyy, mm, dd");

                }
            }
            //lb_eddigiFoglalasok.Items.Add(eddigiFoglalasok);
        }
        
   

        public void lb_eddigiFoglalasok_SelectedIndexChanged(object sender, EventArgs e)
        {
            String start = (lb_eddigiFoglalasok.SelectedItem as Foglalas).foglalasStart.ToString();
            String end = (lb_eddigiFoglalasok.SelectedItem as Foglalas).foglalasEnd.ToString();
            //cal_foglalas.TitleBackColor = Color.Red;
        }
        

        public void CreateReceipt(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           
            float change = 0.00f;

            //this prints the reciept

            Graphics graphic = e.Graphics;

            Font font = new Font("Courier New", 12); //must use a mono spaced font as the spaces need to line up

            float fontHeight = font.GetHeight();

            int startX = 10;
            int startY = 10;
            int offset = 40;

            Rent_A_FlatEntities raf = new Rent_A_FlatEntities();
            
            var aktualisIngatlan = raf.Ingatlans.FirstOrDefault(x => x.Id == currentIngatlanID);
            var aktualisFoglalas = raf.Foglalas.FirstOrDefault(y => y.Id == currentIngatlanID);
            
            String cim = aktualisIngatlan.Cim;            
            String ar = aktualisIngatlan.Ar.ToString();
            String foglalasStart = aktualisFoglalas.foglalasStart.ToString("yyyy. mm. dd.");
            String foglalasEnd = aktualisFoglalas.foglalasEnd.ToString("yyyy. mm. dd.");
            TimeSpan napokSzama = aktualisFoglalas.foglalasEnd.Subtract(aktualisFoglalas.foglalasStart);
            String napok = napokSzama.ToString("dd");
            int osszeg = Convert.ToInt32(napokSzama.Days) * aktualisIngatlan.Ar;

            graphic.DrawString("Rent a Flat", new Font("Courier New", 18), new SolidBrush(Color.Black), startX, startY);
            string top = "Ingatlan megnevezése".PadRight(30) +"LAKÁS VAGY HÁZ?";
            graphic.DrawString(top, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight; //make the spacing consistent
            graphic.DrawString("Cím: ".PadRight(30)+cim, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight; 
            graphic.DrawString("----------------------------------", font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight; 
            graphic.DrawString("Foglalás kezdete: ".PadRight(30)+foglalasStart,font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight; 
            graphic.DrawString("Foglalás vége: ".PadRight(30)+foglalasEnd,font, new SolidBrush(Color.Black), startX, startY + offset);

            //graphic.DrawString(start, font, new SolidBrush(Color.Black), startX, startY + offset);
            //graphic.DrawString(end, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight + 5; //make the spacing consistent

            float totalprice = 0.00f;
            graphic.DrawString("----------------------------------", font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight;
            graphic.DrawString("Eltöltött napok: ".PadRight(30)+napok, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight;
            graphic.DrawString("Ár éjszakánként ".PadRight(30) + ar, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight;
            graphic.DrawString("Összesen fizetendő ".PadRight(30)+osszeg.ToString() + String.Format("{0:c}", totalprice), new Font("Courier New", 12, FontStyle.Bold), new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight;
            offset = offset + (int)fontHeight;
            graphic.DrawString(" ".PadRight(15) + "Üdvözlettel, Rent a Flat csapata! ", font, new SolidBrush(Color.Black), startX, startY + offset);
        }

        private void btn_letoltes_Click(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            //SaveFileDialog saveDialog = new SaveFileDialog();

            PrintDocument printDocument = new PrintDocument();

            printDialog.Document = printDocument; //add the document to the dialog box...        

            printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(CreateReceipt); //add an event handler that will do the printing

            //on a till you will not want to ask the user where to print but this is fine for the test envoironment.

            DialogResult result = printDialog.ShowDialog();

            if (result == DialogResult.OK)
            {
                printDocument.Print();

            }
        }



    } 
}
