﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Rent_A_Flat

{

    
    public partial class Kereses_Form : Form
    {

        Ingatlan foglaltIngatlan;

        public Ingatlan FoglaltIngatlan
        {
            get { return foglaltIngatlan; }
            set { foglaltIngatlan = value; }
        }

        Felhasznalo keresoFelhasznalo;

        public Felhasznalo KeresoFelhasznalo
        {
            get { return keresoFelhasznalo; }
            set { keresoFelhasznalo = value; }
        }
        public Kereses_Form()
        {
            InitializeComponent();
        }

        private void Kereses_Form_Load(object sender, EventArgs e)
        {
            label_ar.BackColor = Color.Transparent; label_cim.BackColor = Color.Transparent;
            label_elerhetoseg.BackColor = Color.Transparent; label_epiteseve.BackColor = Color.Transparent;
            label_felszoba.BackColor = Color.Transparent; label_furdo.BackColor = Color.Transparent;
            label_futes.BackColor = Color.Transparent; label_komfort.BackColor = Color.Transparent;
            label_leiras.BackColor = Color.Transparent; label_parkolas.BackColor = Color.Transparent;
            label_szobakszama.BackColor = Color.Transparent; label_terkep.BackColor = Color.Transparent;
            label_terulet.BackColor = Color.Transparent; label1.BackColor = Color.Transparent;

            rtb_foglaltDatum.Text = "Már foglalt dátumok:";
            
            if (label1.Text=="label1")
            {
                label1.Text = "Jelenleg vendégként böngészed az oldalt, ahhoz, hogy ingatlant tudjál foglalni kérlek jelentkezz be vagy reigsztrálj.";
            } 
            if (keresoFelhasznalo.Nev!="")
            {                
                label1.Text = keresoFelhasznalo.ToString()+", az elemekre kattintva jelennek meg az ingatlan adatai";
            }

            Rent_A_FlatEntities raf = new Rent_A_FlatEntities();

            foreach (Ingatlan a in raf.Ingatlans)
            {
                lb_Ingatlanok.Items.Add(a);
            }

            Foglalas_Form foglalas = new Foglalas_Form();
            rtb_foglaltDatum.Text = foglalas.Foglalt_datumok;


        }

        private Image ConvertBytetoImage(byte[] photo)
        {
            Image newImage;

            using (MemoryStream ms = new MemoryStream(photo, 0, photo.Length))
            {
                ms.Write(photo, 0, photo.Length);
                newImage = Image.FromStream(ms, true);

            }

            return newImage;
        }

        private void lb_Ingatlanok_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                tb_ar.Visible = true; label_ar.Visible = true;
                tb_cim.Visible = true; label_cim.Visible = true;
                tb_terulet.Visible = true; label_terulet.Visible = true;
                tb_szobak.Visible = true; label_szobakszama.Visible = true;
                tb_felszoba.Visible = true; label_felszoba.Visible = true;
                tb_futes.Visible = true; label_futes.Visible = true;
                tb_furdo.Visible = true; label_furdo.Visible = true;
                tb_epitesEve.Visible = true; label_epiteseve.Visible = true;
                tb_komfort.Visible = true; label_komfort.Visible = true;
                tb_parkolas.Visible = true; label_parkolas.Visible = true;
                rtb_leiras.Visible = true; label_leiras.Visible = true;
                tb_elerhetosegek.Visible = true; label_elerhetoseg.Visible = true;
                label_terkep.Visible = true;
                rtb_foglaltDatum.Visible = true; monthCalendar1.Visible = true;
                btn_foglalas.Visible = true;
                pictureBox1.Visible = true;

                
                
                Console.WriteLine(this.lb_Ingatlanok.Items[this.lb_Ingatlanok.SelectedIndex]);
                tb_cim.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Cim;
                tb_terulet.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Terulet.ToString();
                tb_szobak.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Szoba.ToString();
                tb_felszoba.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Felszoba.ToString();
                tb_komfort.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Komfort;
                tb_futes.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Futes;
                tb_furdo.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Furdo.ToString();
                tb_epitesEve.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Epites_eve.ToString("yyyy. mm. dd");
                tb_parkolas.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Parkolas;
                rtb_leiras.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Leiras;
                tb_ar.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Ar.ToString();
                tb_elerhetosegek.Text = (this.lb_Ingatlanok.SelectedItem as Ingatlan).Tulajdonos + ", " +
                    (this.lb_Ingatlanok.SelectedItem as Ingatlan).Email;
                this.pictureBox1.Image = ConvertBytetoImage((this.lb_Ingatlanok.SelectedItem as Ingatlan).Kep);

            } 
            catch(Exception ec)
            {
                Console.WriteLine(ec.Message);
            }
        }

        private void label_terkep_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://www.google.hu/maps/place/" + tb_cim.Text);
            }
            catch { }
        }

        private void btn_foglalas_Click(object sender, EventArgs e)
        {
            foglaltIngatlan = lb_Ingatlanok.SelectedItem as Ingatlan;

            if (lb_Ingatlanok.SelectedItem == null)
            {
                MessageBox.Show("Nem választott ki ingatlant");
            }
            else
            {
               
                //TODO ÁT KELLENE ADNI AZ RTB-NEK DE A LOAD CSAK 1-SZER FUT LE!!!
                Foglalas_Form foglalas = new Foglalas_Form();
                foglalas.CurrentIngatlanID = (lb_Ingatlanok.SelectedItem as Ingatlan).Id;
                if (foglalas.ShowDialog() == DialogResult.OK)
                {

                }
            }

        }

        
    }
}
